# main-menu

linux-update

## general Menu

    1) Package Manager Operations
    2) Self Update
    3) Version Information
    4) Verify Installation
    5) Exit


## sub Menu 
(Package Manager Operations)

APT Operations

    1) Update package lists
    2) Upgrade packages
    3) Remove unused packages
    4) Clean package cache
    5) Back

## Selection:2
(Self Update)

Current version: 0.4.0
Latest version:  0.4.0


## Selection: 3
(Version Information)

Current version: 0.4.0

## Selection: 4
(Verify Installation)

Verification

    [OK] version.txt
    [OK] osdetect.sh
    [OK] self-update.sh
    [OK] menu.sh

## Selection: 5 - EXIT
Goodbye.