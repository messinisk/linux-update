Για πλήρεις σημειώσεις έκδοσης:

[linux-update/releases](https://github.com/messinisk/linux-update/releases)