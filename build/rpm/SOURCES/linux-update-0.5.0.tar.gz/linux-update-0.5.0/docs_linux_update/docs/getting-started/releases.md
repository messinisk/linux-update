For complete release notes:

[https://github.com/messinisk/linux-update/releases](https://github.com/messinisk/linux-update/releases)