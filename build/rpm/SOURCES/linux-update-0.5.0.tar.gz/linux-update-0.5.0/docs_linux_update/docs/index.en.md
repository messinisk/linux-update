# linux-update

Welcome to the linux-update documentation.

Hero

linux-update

Universal Linux Update Utility

Features

- ✔ APT
- ✔ DNF
- ✔ Zypper

- ✔ DEB
- ✔ RPM
- ✔ AppImage

- ✔ Self Update
- ✔ Verification
- ✔ Package Signing

Quick Start

Install
Run
Update

Documentation

Getting Started
User Guide
Developer Guide